package com.qa.zerobank.testcases;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

public class HomePageTestCases extends TestBase {
	
	HomePage homepage;
	LogInPage loginpage;
	
	public HomePageTestCases() {
		super();
	}

	@BeforeMethod(priority = 1)
	public void setup() {
		
		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
	}
	
	@Test(priority = 1)
	public void ValidateHomePage() {
		homepage.assertHomePageTitle();
	}
	
	@Test(priority = 3)
	public void signInButtonTest() {
		loginpage = homepage.clickSigninButton();
		loginpage.assertLoginPageTitle();
		
	}
	@Test(priority = 2)
	public void ValidateLogo() {
		homepage.assertHomePageTitle();
	}
	@AfterMethod
	public void clear() {
		
		driver.close();
		driver.quit();
	}
}