package com.qa.zerobank.testcases;

import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LogInPage;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class LogInPageTestcases extends TestBase {
	
	HomePage homepage;
	LogInPage loginpage;
	AccountSummaryPage accountSummaryPage;

	public LoginPageTestCase() {
		super();
	}

	@BeforeMethod
	public void setup() {

		initialization();
		homepage = new HomePage();
		loginpage = new LogInPage();
		accountSummaryPage = new AccountSummaryPage();
	}

	@Test(priority = 0)
	public void validateLogInPageFunctionality() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		accountSummaryPage.assertAccountSummaryPageTitle();

	}

	@Test(priority = 2)
	public void enterInvalidUserName() {
		loginpage = homepage.clickSigninButton();
		 accountSummaryPage = loginpage.logIn();
		loginpage.enterInvalidUserName();

	}

	@Test(priority = 3)
	public void enterInvaliUserNameAnddPassword() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		LogInPage.enterInvalidUsernameAndPassword();

	}
	@Test(priority = 1)
	public void emptyPassword() {
		// TODO Auto-generated method stub
		loginpage = homepage.clickSigninButton();
		loginpage.emptyPassword();

	}
	@AfterMethod
	public void close() {

		driver.quit();
	}